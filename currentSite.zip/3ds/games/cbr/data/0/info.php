<?php
// CBR include data 1.0 beta

$cbname = "Sporkbob Schitbag";
$cbprefix = "page";
$startsWithZero = true;


$cbPages = 10;

if($startsWithZero){
	$cbPages += 1;
}

$pageText = array(
"Sporkbob Schitbag\n\nEpisode 1: Noochie grab me my belt\nWritten by Slinkybenis",
"Patrick: Spongebob i need to obtain bottled water to be ready to go to god's doorstep\n\nSpongebob: I know yo pink ass not smoking that cheap ass reaggie in my new house\n\nPatrick: Shiee when we gon rob that nigga mr krabs for all his dineros?\n\nSpongebob: I gotta go grab my pipe outta squidwards closet\nYou keep yo pipe in that nigga squidward's closet? You wierd as shit spongebob",
"Spongebob: Yo squiddie can i grab my glock out yo closet real quick\n\nSquidward: If yo bitchass ever call me squiddie again imma shoot yo bitch ass in the face\n\nSpongebob: We bout to rob that nigga mr krabs of everything he got. Im sick of living off minimum wage!\n\nSquidward: Shit u better give me a piece of that bread for you stressing me out for years\n\nSpongebob: I dont owe you shit big nose ass window sucker. Now lemme go get my pipe\n\nSquidward: Nah im keeping that shit now",
"Spongebob: Thats what your bitch ass get\n\nPatrick: When we rob him imma steal this niggas ownership title of the krusty krab :skull:\n\nSpongebob: Yo fat lazy ass cant even take care of gary let alone take care of a business stfu\n\nPatrick: Why u always hating on a nigga tryna feed his kids\n\nSpongebob: Bro u dont got no kids you fucking ate them when you ran out of twinkies fucking psychopath",
"NARRATOR: In the outskirts of the hood...\n\nKrabs: Damn i love taking baths in money!\n\nSpongebob: Run yo pockets suckah!\n\nKrabs: I know your ass aint interrupting my money bath!\n\nPatrick: Yo this nigga think we playing\n\nPlankton: Hold up lil nigga",
"Plankton: Wouldn't it be wise for me to use this time to steal the krabby patty formula?\n\nSpongebob: Shut yo dish rag eating ass rat foot smellin ass lego piece biting ass\n\nKrabs: ITE FUCK THIS YALL NOT GON' INTERRUPT MY MONEY BATH AND GET AWAY WITH IT!!!\n\nPatrick: See thats why i don't like rich muh fuckers, always doing unnecessary wierd shit.\n\nKrabs: IF U DON'T SHUT YOUR BROKE ASS UP\n\nSpongebob: I'm sick of living off 3 pennies a day bro, I'm sick of eating saltine crackers for breakfast",
"Krabs: I KNOW YO UNGRATEFUL ASS AINT TALKING, THATS IT, YOU'RE FIRED!\n\nSpongebob: I don't care, you can lick my dick muh fucker\nFishHead: WHATS THIS?! BREAKING NEWS!!!! KRUSTY KRAB OWNER MR KRABS HAS BEEN EXPOSED BY HIS DAUGHTER AS LEADER OF A LOCAL PEDOPHILE RING!!!\n\nPearl:You're not getting away with it this time dad.\n\nPatrick: Aw shit its the cops!\n\nCop: I heard there was some illegal activity going on. Not if i have anything to say about it.",
"SFX: SMACK!\n\nSFX: *FLICK*\n\nPlankton: Mercy?\n\nCop: You've come far on your journey, but you've made a mistake when you ran into a giga dick and pearl!\n\nPearl: TELL EM GIGADICK!",
"Spongebob: Goodbye my nigga.\n\nSpongebob:Imma make yall wish yall aint never did that.\n\nSpongebob: I got one special tool from squidwards closet.\n\nSpongebob: AN RPG!",
"Cop: You really thought such puny missiles could stop me?\n\nSFX: *SLAM*\n\nCop: Get me out this shit\n\nSpongebob: NIGHT NIGHT",
"Spongebob: Crazy ass day.\n\n\nThe end ok"
);
$pt = json_encode($pageText);
?>