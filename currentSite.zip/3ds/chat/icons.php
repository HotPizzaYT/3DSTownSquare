<!DOCTYPE html>
<!-- saved from url=(0089)https://web.archive.org/web/20211116050941if_/https://3dsplaza.com/chat3/nav.php?loc=icon -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<!-- End Wayback Rewrite JS Include -->

<title>Nav Browser</title>
<style type="text/css">
	a {
		border-bottom: 1px solid black;
		display: block;
	}
</style></head><body><span style="font-size: 80%;">
<a href="nav.php" style="font-size: 85%;">nav index ←</a><br>Emoticon Reference:<br><br>
:)&nbsp;&nbsp;<img src="i/happy.gif" alt="happy"><br>:D&nbsp;&nbsp;<img src="i/icon_cheesygrin.gif" alt="grin"><br>;)&nbsp;&nbsp;<img src="i/icon_wink.gif" alt="wink"><br>;(&nbsp;&nbsp;<img src="i/icon_cry.gif" alt="cry"><br>:con:&nbsp;&nbsp;<img src="i/icon_confused.gif" alt="confused"><br>:@&nbsp;&nbsp;<img src="i/icon_mad.gif" alt="mad"><br>:grr:&nbsp;&nbsp;<img src="i/buy_sweat.png" alt="annoyed"><br>XD&nbsp;&nbsp;<img src="i/ecksdee.png" alt="ecksdee"><br>:omg:&nbsp;&nbsp;<img src="i/icon_amazed.gif" alt="omg"><br>:fp:&nbsp;&nbsp;<img src="i/icon_facepalm.gif" alt="facepalm"><br>:thinking:&nbsp;&nbsp;<img src="i/thinking.png" width="16px" height="16px" alt="thinking"><br>:eyes:&nbsp;&nbsp;<img src="i/eyes.png" style="height:20px" alt="eyes"><br>R(&nbsp;&nbsp;<img src="i/icon_unknown1.png" alt="negitiveepicface"><br>RB:&nbsp;&nbsp;<img src="i/rbow.png" alt="rainbowepicface"><br>R:&nbsp;&nbsp;<img src="i/epic.png" alt="epicface"><br>:ponything:&nbsp;&nbsp;<img src="i/icon_ponything.jpg" alt="ponything"><br>:waah:&nbsp;&nbsp;<img src="i/waah.gif" alt="waah"><br>:nuu:&nbsp;&nbsp;<img src="i/nuu.gif" alt="nuu"><br>:caps:&nbsp;&nbsp;<img src="i/caps.gif" alt="caps"><br>:lenny:&nbsp;&nbsp;( ͡° ͜ʖ ͡°)<br>:shrug:&nbsp;&nbsp;¯\_(ツ)_/¯<br>:megusta:&nbsp;&nbsp;<img src="i/icon_megusta.jpg" alt="megusta"><br>:lol:&nbsp;&nbsp;<img src="i/lol.png" alt="lol"><br>:troll:&nbsp;&nbsp;<img src="i/icon_trollface.png" alt="troll"><br>:no:&nbsp;&nbsp;<img src="i/no.png" alt="no"><br>:pface:&nbsp;&nbsp;<img src="i/pokerface.png" alt="pokerface"><br>:raeg:&nbsp;&nbsp;<img src="i/raeg.png" alt="raeg"><br>:ohplz:&nbsp;&nbsp;<img src="i/please.png" alt="ohplz"><br>:ydsay:&nbsp;&nbsp;<img src="i/buy_youdontsay.png" alt="ydsay"><br>:falone:&nbsp;&nbsp;<img src="i/icon_foreveralone.jpg" alt="falone"><br>:doge:&nbsp;&nbsp;<img src="i/doge.png" alt="&lt;DOGE (not the currency)&gt;"><br>:trig:&nbsp;&nbsp;<img src="i/triggered.jpg" alt="triggered"><br>:wolfthing:&nbsp;&nbsp;<img src="i/wolfthing.gif" alt="&lt;•o•&gt;"><br>:mccreeper:&nbsp;&nbsp;<img src="i/icon_mccreeper.png" width="16px" height="16px" alt="mccreeper"><br>:mchappy:&nbsp;&nbsp;<img src="i/icon_mchappy.png" width="16px" height="16px" alt="mchappy"><br>:sonic:&nbsp;&nbsp;<img src="i/buy_sonic.png" alt="sonic"><br>:yoshi:&nbsp;&nbsp;<img src="i/buy_yoshi.png" alt="yoshi"><br>:mario:&nbsp;&nbsp;<img src="i/icon_mario.png" alt="mario"><br>:luigi:&nbsp;&nbsp;<img src="i/icon_luigi.png" alt="luigi"><br>:weegee:&nbsp;&nbsp;<img src="i/weegee.png" alt="weegee"><br>:pokeball:&nbsp;&nbsp;<img src="i/buy_pokeball.jpg" alt="pokeball"><br>:ds:&nbsp;&nbsp;<img src="i/icon_ds.gif" alt="ds"><br>:baby:&nbsp;&nbsp;<img src="i/icon_baby.png" alt="baby"><br>:bheart:&nbsp;&nbsp;<img src="i/icon_bheart.gif" alt="heart"><br>:taco:&nbsp;&nbsp;<img src="i/icon_taco.gif" alt="taco"><br>:burger:&nbsp;&nbsp;<img src="i/icon_burger.gif" alt="burger"><br>:icecream:&nbsp;&nbsp;<img src="i/icon_icecream.gif" alt="icecream"><br>:cake:&nbsp;&nbsp;<img src="i/icon_cake.gif" alt="cake"><br>:file:&nbsp;&nbsp;<img src="i/icon_file.png" alt="file"><br>:rec:&nbsp;&nbsp;<img src="i/icon_recommended.png" alt="RECOMMENDED"><br>:stb:&nbsp;&nbsp;<img src="i/icon_stable.png" alt="STABLE"><br>:uns:&nbsp;&nbsp;<img src="i/icon_unstable.png" alt="UNSTABLE"><br>:pre:&nbsp;&nbsp;<img src="i/icon_prerelease.png" alt="PRERELEASE"><br></span>
<!--
     FILE ARCHIVED ON 05:09:41 Nov 16, 2021 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:12:19 Apr 25, 2022.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
-->
<!--
playback timings (ms):
  captures_list: 360.796
  exclusion.robots: 218.18
  exclusion.robots.policy: 218.17
  xauthn.identify: 176.327
  xauthn.chkprivs: 41.583
  cdx.remote: 0.06
  esindex: 0.009
  LoadShardBlock: 108.603 (3)
  PetaboxLoader3.datanode: 60.918 (4)
  CDXLines.iter: 21.586 (3)
  PetaboxLoader3.resolve: 66.213 (2)
  load_resource: 51.931
--></body></html>