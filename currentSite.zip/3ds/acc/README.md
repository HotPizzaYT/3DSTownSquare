# HxLogin
A JSON login system designed for PHP servers without MySQL.
# How to install
Just drag and drop files to any folder on your server and voila, enjoy having a login system for your website.
